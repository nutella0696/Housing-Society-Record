<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housingsocietyrecord";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>


</head>
<body>

<h1 align="center">Delete RECORD</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>H_ID</th>
<th>Area_sqm</th>
<th>Block</th>
<th>Rooms</th>



<?php
$sql = "SELECT * FROM house";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['H_ID'];?></td>
<td> <?php  echo $row['Area_sqm'];?></td>
<td> <?php  echo $row['Block'];?></td>
<td> <?php  echo $row['Rooms'];?></td>





 <td><a href="deletehouse.php?edit_id=<?php echo $row['H_ID']; ?>" alt="edit" >Delete Record</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>