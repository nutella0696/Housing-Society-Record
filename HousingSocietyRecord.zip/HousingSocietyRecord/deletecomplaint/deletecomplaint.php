<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housingsocietyrecord";

$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else
{ 
//echo "Connected successfully";
}

if(isset($_GET['edit_id'])){
 $sql = "DELETE FROM complaint WHERE CID=" .$_GET['edit_id'];
 $result = mysqli_query($conn, $sql);
 

}

?>
<!doctype html>
<html>
<head>

</head>


<body>

<h1 align="center">Deleted RECORD</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>CID</th>
<th>Status</th>
<th>C_Date</th>
<th>Comment</th>
<th>Category</th>




</tr>
<?php
$sql = "SELECT * FROM complaint";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['CID'];?></td>
<td> <?php  echo $row['Status'];?></td>
<td> <?php  echo $row['C_Date'];?></td>
<td> <?php  echo $row['Comment'];?></td>
<td> <?php  echo $row['Category'];?></td>




 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>

</body>
</html>