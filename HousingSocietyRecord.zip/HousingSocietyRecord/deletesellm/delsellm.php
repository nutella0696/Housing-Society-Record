<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housingsocietyrecord";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>


</head>
<body>

<h1 align="center">Delete RECORD</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Sell_ID</th>
<th>FullPrice</th>
<th>InstallmentPrice</th>
<th>Selling_Date</th>
<



<?php
$sql = "SELECT * FROM sell_m";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['Sell_ID'];?></td>
<td> <?php  echo $row['FullPrice'];?></td>
<td> <?php  echo $row['InstallmentPrice'];?></td>
<td> <?php  echo $row['Selling_Date'];?></td>






 <td><a href="deletesellm.php?edit_id=<?php echo $row['Sell_ID']; ?>" alt="edit" >Delete Record</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>