<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housingsocietyrecord";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center">**********Administrator Data**********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>User ID</th>
<th>Password</th>
<th>Speciality</th>
<th>Address</th>


</tr>
<?php
$sql = "SELECT * FROM admin";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>
<td> <?php  echo $row['User_ID'];?></td>
<td> <?php  echo $row['Password'];?></td>
<td> <?php  echo $row['Speciality'];?></td>
<td> <?php  echo $row['Address'];?></td>



 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>