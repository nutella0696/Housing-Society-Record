<?php
$aa= $_POST['aa'];
$bb= $_POST['bb'];
$cc= $_POST['cc'];
$dd= $_POST['dd'];
$ab= $_POST['ab'];
$a= $_POST['a'];
$b= $_POST['b'];
$c= $_POST['c'];
$d= $_POST['d'];
$e= $_POST['e'];
$f= $_POST['f'];
$g= $_POST['g'];
$h= $_POST['h'];
$i= $_POST['i'];
$j= $_POST['j'];
$k= $_POST['k'];
$l= $_POST['l'];
$m= $_POST['m'];
$n= $_POST['n'];
$o= $_POST['o'];
$p= $_POST['p'];
$q= $_POST['q'];
$r= $_POST['r'];
$s= $_POST['s'];
$t= $_POST['t'];
$u= $_POST['u'];
$v= $_POST['v'];
$w= $_POST['w'];
$x= $_POST['x'];
$y= $_POST['y'];
$z= $_POST['z'];




$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housingsocietyrecord";

// Create connection
$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
{ 
echo "Connected successfully";
}
$q="INSERT INTO Admin VALUES('$aa','$bb','$cc','$dd')";
$q="INSERT INTO Society VALUES('$a','$b','$c','$d','$e')";
$q="INSERT INTO House VALUES('$f','$g','$h','$i')";
$q="INSERT INTO Sell_m VALUES('$j','$k','$l','$m')";
$q="INSERT INTO Rent VALUES('$n','$o','$p')";
$q="INSERT INTO Customer VALUES('$q','$r','$s','$t','$u')";
$q="INSERT INTO Complaint VALUES('$v','$w','$x','$y','$z')";
if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $q . "<br>" . $conn->error;
}

?>