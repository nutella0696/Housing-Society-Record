<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housingsocietyrecord";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>


</head>
<body>

<h1 align="center">Delete RECORD</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>CustomerID</th>
<th>FullName</th>
<th>A_ID</th>
<th>Contact</th>
<th>City</th>



<?php
$sql = "SELECT * FROM customer";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['CustomerID'];?></td>
<td> <?php  echo $row['FullName'];?></td>
<td> <?php  echo $row['A_ID'];?></td>
<td> <?php  echo $row['Contact'];?></td>
<td> <?php  echo $row['City'];?></td>
<td> <?php  echo $row['address'];?></td>




 <td><a href="deletecustomer.php?edit_id=<?php echo $row['CustomerID']; ?>" alt="edit" >Delete Record</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>