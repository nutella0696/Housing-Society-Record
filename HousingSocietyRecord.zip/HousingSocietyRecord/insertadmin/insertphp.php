<?php
$aa= $_POST['aa'];
$bb= $_POST['bb'];
$cc= $_POST['cc'];
$dd= $_POST['dd'];
$ab= $_POST['ab'];



$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housingsocietyrecord";

// Create connection
$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
{ 
echo "Connected successfully<br>";
}
$q="INSERT INTO Admin VALUES('$aa','$bb','$cc','$dd')";
if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $q . "<br>" . $conn->error;
}

?>