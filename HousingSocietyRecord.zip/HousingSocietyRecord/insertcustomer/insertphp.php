<?php
$q= $_POST['q'];
$r= $_POST['r'];
$s= $_POST['s'];
$t= $_POST['t'];
$u= $_POST['u'];




$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housingsocietyrecord";

// Create connection
$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
{ 
echo "Connected successfully<br>";
}
$q="INSERT INTO Customer VALUES('$q','$r','$s','$t','$u')";
if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $q . "<br>" . $conn->error;
}

?>