<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housingsocietyrecord";// 1st change database name

$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else
{ 
//echo "Connected successfully";
}

if(isset($_GET['edit_id'])){
	
 $sql = "SELECT * FROM admin WHERE User_ID=" .$_GET['edit_id'];
 // 2nd change table name and carno ya id jis ko ap change krna chaho
 $result = mysqli_query($conn, $sql);
 //$row = mysqli_fetch_array($result);

}
if(isset($_POST['btn-update'])){
 $aa = $_POST['aa'];
 $bb = $_POST['bb'];
 $cc = $_POST['cc'];
  $dd = $_POST['dd'];
  
 
// 3rd pa neechy jao or table k column name change kro
// 4th number pay yaha pay car_category ki jaga table name likho
 $update = "UPDATE admin SET Password='$bb',  Speciality='$cc'  , Address='$dd'  where User_ID='$aa' ";
if ($conn->query($update) === TRUE) {
    echo "<script>alert('Do you want To update Record ?');</script>";
} else {
    echo "Error: " . $update . "<br>" . $conn->error;
}
}
?>
<!doctype html>
<html>
<head>


</head>


<body>

<form method="post">
<h1>Update Record</h1>
<input type="text" name="aa" placeholder="User_ID" value="<?php echo $row['User_ID']; ?>"><br>
<input type="text"  name="bb" placeholder="Password" value="<?php echo $row['Password']; ?>"><br>
<input type="text"  name="cc" placeholder="Speciality" value="<?php echo $row['Speciality']; ?>"><br>
<input type="text" name="dd" placeholder="Address" value="<?php echo $row['Address']; ?>"><br>


<button type="submit" name="btn-update" id="btn-update" ><strong>Update</strong></button>
<a href="record.php"><button type="button" value="button">Cancel</button></a>
</form>

</body>
</html>