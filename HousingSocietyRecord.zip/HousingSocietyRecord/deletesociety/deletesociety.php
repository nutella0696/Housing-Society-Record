<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housingsocietyrecord";

$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else
{ 
//echo "Connected successfully";
}

if(isset($_GET['edit_id'])){
 $sql = "DELETE FROM Society WHERE SID=" .$_GET['edit_id'];
 $result = mysqli_query($conn, $sql);
 

}

?>
<!doctype html>
<html>
<head>

</head>


<body>

<h1 align="center">Deleted RECORD</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>SID</th>
<th>SocietyName</th>
<th>Address</th>
<th>NoOfPlots</th>
<th>NoOfHouses</th>


</tr>
<?php
$sql = "SELECT * FROM Society";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['SID'];?></td>
<td> <?php  echo $row['Society_Name'];?></td>
<td> <?php  echo $row['Address'];?></td>
<td> <?php  echo $row['NoOfPlots'];?></td>
<td> <?php  echo $row['NoOfHouses'];?></td>



 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>

</body>
</html>