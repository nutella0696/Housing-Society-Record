<?php
$j= $_POST['j'];
$k= $_POST['k'];
$l= $_POST['l'];
$m= $_POST['m'];




$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housingsocietyrecord";

// Create connection
$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
{ 
echo "Connected successfully<br>";
}

$q="INSERT INTO Sell_m VALUES('$j','$k','$l','$m')";
if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $q . "<br>" . $conn->error;
}

?>