<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housingsocietyrecord";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center">**********Society Data**********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Society Name</th>
<th>Society Number</th>
<th>Address</th>
<th>Number of Houses</th>
<th>Number of Plots</th>

</tr>
<?php
$sql = "SELECT * FROM society";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>
<td> <?php  echo $row['SID'];?></td>
<td> <?php  echo $row['Society_Name'];?></td>
<td> <?php  echo $row['Address'];?></td>
<td> <?php  echo $row['NoOfHouses'];?></td>
<td> <?php  echo $row['NoOfPlots'];?></td>


 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>