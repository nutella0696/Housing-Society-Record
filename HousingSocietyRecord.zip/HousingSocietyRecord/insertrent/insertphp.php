<?php
$n= $_POST['n'];
$o= $_POST['o'];
$p= $_POST['p'];




$servername = "localhost";
$username = "root";
$password = "";
$dbname = "housingsocietyrecord";

// Create connection
$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
{ 
echo "Connected successfully <br>";
}

$q="INSERT INTO Rent VALUES('$n','$o','$p')";
if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $q . "<br>" . $conn->error;
}

?>